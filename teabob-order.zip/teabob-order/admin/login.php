<?php include('../config/constants.php') ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teabob - Order Teabob Online</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>


<body>

    <div class="login">
        <h1 class="text-center">Login</h1>
        <br><br>

        <?php 
        if(isset($_SESSION['login']))
        {
            echo $_SESSION['login']; 
            unset($_SESSION['login']);   
        }

        if(isset($_SESSION['no-login-msg']))
        {
            echo $_SESSION['no-login-msg']; 
            unset($_SESSION['no-login-msg']); 
        }
        ?>
        <br>
        <!-- login form start -->
        <form action="" method="POST" class="text-center">
        Username:<br><br>
        <input style="padding:2%; border-radius:10px" type="text" name="username" placeholder="Enter Username"><br><br>

        Password: <br><br>
        <input style="padding:2%; border-radius:10px" type="password" name="password" placeholder="Enter Password"><br><br>

        <input type="submit" name="submit" value="Login" class="btn-login">
        </form>
        <!-- login form end -->
<br>
        <p class="text-center">Team IT Movers, 2021</p>
    </div>
    
</body>
</html>

<?php 
if(isset($_POST['submit']))
{
    //Process for login
    //Get data from login form
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    //$username = mysqli_escape_string($conn, $_POST['username']);
    
   //$raw_password = md5($_POST['password']);
    //$password = mysqli_escape_string($conn, $raw_password['raw_password']);

    //SQL to check if username and password exists in DB
    $sql = "SELECT * FROM tbl_admin WHERE username = '$username' AND password = '$password'";

    //Execute query
    $res = mysqli_query($conn,$sql);

    //count rows to check if user exists
    $count = mysqli_num_rows($res);

    if($count==1)
    {   
        //User found,login success
        $_SESSION['login'] = "<div class='success'>Login Successful.</div>";
        $_SESSION['user'] = $username; //Check if user is logged in.
        //Redirect to dashboard
        header('location:'.SITEURL.'admin/index.php');
    }
    else
    {
        //User not found,login failed
        $_SESSION['login'] = "<div class='error text-center'>Username or password did not match</div>";
        //Redirect to login
        header('location:'.SITEURL.'admin/login.php');
    }

}



?>