<?php include('partials/menu.php'); ?>


    <!-- Main content start -->
    <div class="main-content">
        <div class="wrapper">


           <?php if(isset($_SESSION['login']))
                {
                    echo $_SESSION['login']; //display ADD session msg
                    unset($_SESSION['login']); //remove the session msg after refresh
                } ?><br>

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql = "SELECT * FROM tbl_category";
                        //execute query
                        $res = mysqli_query($conn, $sql);
                        //count rows
                        $count = mysqli_num_rows($res);
                    ?>
                    <h1><?php echo $count; ?></h1>
                    <br>
                    Categories
                </div> 

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql2 = "SELECT * FROM tbl_food";
                        //execute query
                        $res2 = mysqli_query($conn, $sql2);
                        //count rows
                        $count2 = mysqli_num_rows($res2);
                    ?>
                    <h1><?php echo $count2; ?></h1>
                    <br>
                    Foods
                </div> 

                <div class="col-4 text-center">

                     <?php 
                        //sql query
                        $sql3 = "SELECT * FROM tbl_order";
                        //execute query
                        $res3 = mysqli_query($conn, $sql3);
                        //count rows
                        $count3 = mysqli_num_rows($res3);
                    ?>
                    <h1><?php echo $count3; ?></h1>
                    <br>
                    Total Orders
                </div> 

                <div class="col-4 text-center">

                    <?php 
                        //Create sql query to get total revenue generated
                        //Aggregate functionin sql
                        $sql4 = "SELECT SUM(total)AS total FROM tbl_order WHERE status='Delivered'";

                        //execute the query
                        $res4 = mysqli_query($conn, $sql4);
                        //get value
                        $row4 = mysqli_fetch_assoc($res4);

                        //get total revenue
                        $total_revenue = $row4['total'];
                    ?>
                    <h1><?php echo $total_revenue; ?></h1>
                    <br>
                    Revenue Generated 
                </div> 

        </div>
        <div class="clearfix"></div>
    </div>
<!-- Main content start -->
<div class="main-content">
    <div class="wrapper">
        
        <h1>Manage Categories</h1>


        <?php
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add']; //display ADD session msg
                unset($_SESSION['add']); //remove the session msg after refresh
            }

            if(isset($_SESSION['remove']))
            {
                echo $_SESSION['remove']; //display session msg
                unset($_SESSION['remove']); //remove the session msg after refresh
            }

            if(isset($_SESSION['delete']))
            {
                echo $_SESSION['delete']; //display session msg
                unset($_SESSION['delete']); //remove the session msg after refresh
            }

            if(isset($_SESSION['no-category-found']))
            {
                echo $_SESSION['no-category-found']; //display session msg
                unset($_SESSION['no-category-found']); //remove the session msg after refresh
            }

            if(isset($_SESSION['update']))
            {
                echo $_SESSION['update']; //display session msg
                unset($_SESSION['update']); //remove the session msg after refresh
            }

            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload']; //display session msg
                unset($_SESSION['upload']); //remove the session msg after refresh
            }

            if(isset($_SESSION['failed-remove']))
            {
                echo $_SESSION['failed-remove']; //display session msg
                unset($_SESSION['failed-remove']); //remove the session msg after refresh
            }

        ?>
        <br><br>
        <!-- Button to add -->
        <a href="<?php echo SITEURL; ?>admin/add-category.php" class="btn-primary">Add Category</a>
            <br /><br /><br />

        <table class="tbl-full">
                <tr>
                    <th>C.N.</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Action</th>
                </tr> 

                <?php
                    //View table
                    $sql = "SELECT * FROM tbl_category";
                    //execute query
                    $res = mysqli_query($conn, $sql);
                    //count rows
                    $count= mysqli_num_rows($res);

                    //Create category number
                    $sn=1;

                    //Check if DB has data
                    if($count>0)
                    {
                        //Has data
                        //display data
                        while($row=mysqli_fetch_assoc($res))
                        {
                            $id = $row['id'];
                            $title = $row['title'];
                            $image_name = $row['image_name'];
                            $featured = $row['featured'];
                            $active = $row['active'];

                            ?>

                                <tr>
                                    <td><?php echo $sn++; ?></td>
                                    <td><?php echo $title; ?></td>

                                    <td>
                                        <?php
                                            //Check if img name is available
                                            if($image_name!="")
                                            {
                                                //display img
                                                ?>
                                                <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" width="100px">
                                                
                                                <?php
                                                
                                            }
                                            else
                                            {
                                                //Display msg
                                                echo "No image available";
                                            }
                                        ?>
                                    </td>

                                    <td><?php echo $featured; ?></td>
                                    <td><?php echo $active; ?></td>
                                    <td>
                                        <a href="<?php echo SITEURL; ?>admin/update-category.php?id=<?php echo $id; ?>" class="btn-secondary">Update</a>
                                        <a href="<?php echo SITEURL; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete</a>
                                    </td>
                                </tr>        
                            
                            <?php
                        }
                    }
                    else
                    {
                        //No data
                        //display msg inside <table>
                        ?>
                        <tr>
                            <td colspan="6"><div class="error">No Categories at the Moment.</div></td>
                        </tr>

                        <?php
                    }

                ?>
                
                

                

            </table>

    </div>

    
</div>

    

    <!-- Main content end -->

<?php include('partials/footer.php'); ?>