<?php include('partials/menu.php'); ?>

<!-- Main content start -->
<div class="main-content">
    <div class="wrapper">
        
        <h1>Manage Categories</h1>
        <br><br>

        <?php
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add']; //display ADD session msg
                unset($_SESSION['add']); //remove the session msg after refresh
            }

            if(isset($_SESSION['remove']))
            {
                echo $_SESSION['remove']; //display session msg
                unset($_SESSION['remove']); //remove the session msg after refresh
            }

            if(isset($_SESSION['delete']))
            {
                echo $_SESSION['delete']; //display session msg
                unset($_SESSION['delete']); //remove the session msg after refresh
            }

            if(isset($_SESSION['no-category-found']))
            {
                echo $_SESSION['no-category-found']; //display session msg
                unset($_SESSION['no-category-found']); //remove the session msg after refresh
            }

            if(isset($_SESSION['update']))
            {
                echo $_SESSION['update']; //display session msg
                unset($_SESSION['update']); //remove the session msg after refresh
            }

            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload']; //display session msg
                unset($_SESSION['upload']); //remove the session msg after refresh
            }

            if(isset($_SESSION['failed-remove']))
            {
                echo $_SESSION['failed-remove']; //display session msg
                unset($_SESSION['failed-remove']); //remove the session msg after refresh
            }

        ?>
        <br><br>
        <!-- Button to add -->
        <a href="<?php echo SITEURL; ?>admin/add-category.php" class="btn-primary">Add Category</a>
            <br /><br /><br />

        <table class="tbl-full">
                <tr>
                    <th>C.N.</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Action</th>
                </tr> 

                <?php
                    //View table
                    $sql = "SELECT * FROM tbl_category";
                    //execute query
                    $res = mysqli_query($conn, $sql);
                    //count rows
                    $count= mysqli_num_rows($res);

                    //Create category number
                    $sn=1;

                    //Check if DB has data
                    if($count>0)
                    {
                        //Has data
                        //display data
                        while($row=mysqli_fetch_assoc($res))
                        {
                            $id = $row['id'];
                            $title = $row['title'];
                            $image_name = $row['image_name'];
                            $featured = $row['featured'];
                            $active = $row['active'];

                            ?>

                                <tr>
                                    <td><?php echo $sn++; ?></td>
                                    <td><?php echo $title; ?></td>

                                    <td>
                                        <?php
                                            //Check if img name is available
                                            if($image_name!="")
                                            {
                                                //display img
                                                ?>
                                                <img src="<?php echo SITEURL; ?>images/category/<?php echo $image_name; ?>" width="100px">
                                                
                                                <?php
                                                
                                            }
                                            else
                                            {
                                                //Display msg
                                                echo "No image available";
                                            }
                                        ?>
                                    </td>

                                    <td><?php echo $featured; ?></td>
                                    <td><?php echo $active; ?></td>
                                    <td>
                                        <a href="<?php echo SITEURL; ?>admin/update-category.php?id=<?php echo $id; ?>" class="btn-secondary">Update</a>
                                        <a href="<?php echo SITEURL; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete</a>
                                    </td>
                                </tr>        
                            
                            <?php
                        }
                    }
                    else
                    {
                        //No data
                        //display msg inside <table>
                        ?>
                        <tr>
                            <td colspan="6"><div class="error">No Categories at the Moment.</div></td>
                        </tr>

                        <?php
                    }

                ?>
                
                

                

            </table>

    </div>

    
</div>

    

    <!-- Main content end -->

<?php include('partials/footer.php'); ?>