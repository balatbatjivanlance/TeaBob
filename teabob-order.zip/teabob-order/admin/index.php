<?php include('partials/menu.php') ?>


    <!-- Main content start -->
    <div class="main-content">
        <div class="wrapper">


           <?php if(isset($_SESSION['login']))
                {
                    echo $_SESSION['login']; //display ADD session msg
                    unset($_SESSION['login']); //remove the session msg after refresh
                } ?><br>

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql = "SELECT * FROM tbl_category";
                        //execute query
                        $res = mysqli_query($conn, $sql);
                        //count rows
                        $count = mysqli_num_rows($res);
                    ?>
                    <h1><?php echo $count; ?></h1>
                    <br>
                    Categories
                </div> 

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql2 = "SELECT * FROM tbl_food";
                        //execute query
                        $res2 = mysqli_query($conn, $sql2);
                        //count rows
                        $count2 = mysqli_num_rows($res2);
                    ?>
                    <h1><?php echo $count2; ?></h1>
                    <br>
                    Foods
                </div> 

                <div class="col-4 text-center">

                     <?php 
                        //sql query
                        $sql3 = "SELECT * FROM tbl_order";
                        //execute query
                        $res3 = mysqli_query($conn, $sql3);
                        //count rows
                        $count3 = mysqli_num_rows($res3);
                    ?>
                    <h1><?php echo $count3; ?></h1>
                    <br>
                    Total Orders
                </div> 

                <div class="col-4 text-center">

                    <?php 
                        //Create sql query to get total revenue generated
                        //Aggregate functionin sql
                        $sql4 = "SELECT SUM(total)AS total FROM tbl_order WHERE status='Delivered'";

                        //execute the query
                        $res4 = mysqli_query($conn, $sql4);
                        //get value
                        $row4 = mysqli_fetch_assoc($res4);

                        //get total revenue
                        $total_revenue = $row4['total'];
                    ?>
                    <h1><?php echo $total_revenue; ?></h1>
                    <br>
                    Revenue Generated 
                </div> 

        </div>
        <div class="clearfix"></div>
    </div>

    <!-- Main content start -->
    <div class="main-content">
        <div class="wrapper">
            <h1>Manage Admin</h1>
            <br />

            <?php
                
            
                if(isset($_SESSION['add']))
                {
                    echo $_SESSION['add']; //display ADD session msg
                    unset($_SESSION['add']); //remove the session msg after refresh
                }

                if(isset($_SESSION['delete']))
                {
                    echo $_SESSION['delete']; //display DELETE session msg
                    unset($_SESSION['delete']); //remove the session msg after refresh
                }

                if(isset($_SESSION['update']))
                {
                    echo $_SESSION['update']; //display UPDATE session msg
                    unset($_SESSION['update']); //remove the session msg after refresh
                }

                if(isset($_SESSION['user-not-found']))
                {
                    echo $_SESSION['user-not-found']; //display USER NOT FOUND session msg
                    unset($_SESSION['user-not-found']); //remove the session msg after refresh
                }

                if(isset($_SESSION['password-not-match']))
                {
                    echo $_SESSION['password-not-match']; //display PASSWORD NOT MATCH session msg
                    unset($_SESSION['password-not-match']); //remove the session msg after refresh
                }

                if(isset($_SESSION['change-password']))
                {
                    echo $_SESSION['change-password']; //display CHANGE PASSWORD session msg
                    unset($_SESSION['change-password']); //remove the session msg after refresh
                }

            ?>

<br />

            <!-- Button to add admin -->
            <a href="add-admin.php" class="btn-primary">Add admin</a>
            <br /><br /><br />
            
            <table class="tbl-full">
                <tr>
                    <th>A.N.</th>
                    <th>Full name</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr> 

                <?php 
                    //Query to Select from tbl_admin on DB
                    $sql = "SELECT * FROM tbl_admin";
                    //Execute Query
                    $res = mysqli_query($conn,$sql);

                    //Check if query is executed
                    if($res==TRUE)
                    {
                        //Count rows to check if we have data in DB
                        $count = mysqli_num_rows($res); //function to get all rows in DB
                        
                        $an = 1; //To auto-increment ID
                        
                        //Check num of rows
                        if($count>0)
                        {
                            //DB has data
                            while($rows=mysqli_fetch_assoc($res))
                            {
                                //Using while loop to put data from DB to webpage


                                //get individual data
                                $id = $rows['id'];
                                $full_name = $rows['full_name'];
                                $username = $rows['username'];

                                //Display the values to table
                                ?>

                        <tr>
                            <td><?php echo $an++; ?></td>
                            <td><?php echo $full_name; ?></td>
                            <td><?php echo $username; ?></td>
                            <td>
                                <a href="<?php echo SITEURL; ?>admin/update-password.php?id=<?php echo $id; ?>" class="btn-primary">Change Password</a>
                                <a href="<?php echo SITEURL; ?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary">Update</a>
                                <a href="<?php echo SITEURL; ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger">Delete</a>
                            </td>
                        </tr>  

                                <?php
                            }
                        }
                        else
                        {
                            //DB has no data
                        }
                    }

                ?>
                
                

            </table>

                
            </div>

        </div>

    
    </div>

    

    <!-- Main content end -->

<?php include('partials/footer.php') ?>