<?php 
    include('../config/constants.php');

    //Check if id and image_name value is set
    if(isset($_GET['id']) AND isset($_GET['image_name']))
    {
        //get the value and delete
        $id = $_GET['id'];
        $image_name = $_GET['image_name'];

        //Remove img file from images/category folder
        if($image_name != "")
        {
            //Img available, remove
            $path = "../images/category/".$image_name;
            //remove img
            $remove = unlink($path);

            //if delete failed, put error msg and stop process
            if($remove==false)
            {
                //Set session msg
                $_SESSION['remove'] = "<div class='error'>Failed to Delete Image.</div>";
                header('location:'.SITEURL.'admin/manage-category.php');
                //stop process
                die();
            }
        }

        //Delete from DB
        $sql = "DELETE FROM tbl_category WHERE id=$id";
        //execute query
        $res = mysqli_query($conn,$sql);

        //check if data is deleted from DB
        if($res==true)
        {
            //Success
            $_SESSION['delete'] = "<div class='success'>Category Deleted.</div>";
                header('location:'.SITEURL.'admin/manage-category.php');

        }
        else
        {
            //Fail
            $_SESSION['delete'] = "<div class='error'>Category Delete Failed.</div>";
                header('location:'.SITEURL.'admin/manage-category.php');
        }

       
    }
    else
    {
        //Redirect to category page
        header('location:'.SITEURL.'admin/manage-category.php');
    }
?>


