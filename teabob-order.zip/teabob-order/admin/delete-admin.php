<?php

    //include constants.php file here
    include('../config/constants.php');

    //1. Get the ID of the admin to be deleted
    $id = $_GET['id'];

    //2. Create SQL query to delete
    $sql = "DELETE FROM tbl_admin WHERE id=$id";

    //Execute Query
    $res = mysqli_query($conn, $sql);

    // Check if query is executed
    if($res==true)
    {
       
       //Create session variable to display msg
       $_SESSION['delete'] = "<div class='success'>Admin deleted successfully.</div>";
       //Redirect to manage-admin.php
       header('location:'.SITEURL.'admin/manage-admin.php');
    }
    else
    {
        $_SESSION['delete'] = "<div class='error'>Admin delete failed.</div>";
        header('location:'.SITEURL.'admin/manage-admin.php');
    }

   

?>