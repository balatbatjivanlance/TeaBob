<?php 
    include('../config/constants.php'); 
    include('login-check.php');
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teabob - Admin</title>
  

    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <!-- Menu start -->

        <div class="navbar">
        
        <img src="../images/tealogopng.png" alt="Restaurant Logo" class="img-responsive">
        <p class="navp">Teabob</p>
        <ul>

            <li><a href="index.php" class="btn-menu">Home</a></li>
            <li><a href="manage-category.php" class="btn-menu">Category</a></li>
            <li><a href="manage-food.php" class="btn-menu">Food</a></li>
            <li><a href="manage-order.php" class="btn-menu">Order</a></li>
            <li><a href="logout.php" class="btn-menu">Logout</a></li>
        </ul>
        </div> 
 
    <!-- Menu end -->