<?php 
    //check if the user is logged in
    if(!isset($_SESSION['user']))
    {
        //User not logged in
        //Redirect to login page with msg
        $_SESSION['no-login-msg'] = "<div class='error text-center'>Please log in to access panel.</div>";
        //redirect to login.php
        header('location:'.SITEURL.'admin/login.php');
    }

?>
