<!-- Footer start -->
<div class="footer">
    <div class="wrapper">
    <p class="text-center">2021 All rights reserved, Team IT Movers</p>
        </div> 
    </div>
    <!-- Footer end -->
</body>
</html>