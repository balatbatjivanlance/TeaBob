<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Category</h1>
        <br><br>

        <?php
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add']; //display ADD session msg
                unset($_SESSION['add']); //remove the session msg after refresh
            }

            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload']; //display ADD session msg
                unset($_SESSION['upload']); //remove the session msg after refresh
            }
        ?>
        <br><br>

        <!-- Form start -->
        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title: </td>
                    <td>
                        <input type="text" name="title" placeholder="Category title">
                    </td>
                </tr>

                <tr>
                    <td>Upload Image: </td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>

                <tr>
                    <td>Featured: </td>
                    <td>
                        <input type="radio" name="featured" value="Yes"> Yes
                        <input type="radio" name="featured" value="No"> No
                    </td>
                </tr>

                <tr>
                    <td>Active: </td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                        <input type="radio" name="active" value="No"> No
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Category" class="btn-secondary">
                    </td>
                </tr>
            
            </table>
        </form>
        <!-- Form end -->

        <?php

            //Check if button is clicked
            if(isset($_POST['submit']))
            {
                //Get the value from form
                $title = $_POST['title'];

                //Radio input: Check if a button is selected
                if(isset($_POST['featured']))
                {
                    $featured = $_POST['featured'];
                }
                else
                {
                    //Set default value of radio button if none is selected
                    $featured = "No";
                }
                
                if(isset($_POST['active']))
                {
                    $active = $_POST['active'];
                }
                else
                {
                    //Set default value of radio button if none is selected
                    $active = "No";
                }

                //Check if image is selected
                //print_r($_FILES['image']);

                //die(); //break code

                if(isset($_FILES['image']['name']))
                {
                    //set credentials to upload
                    $image_name = $_FILES['image']['name'];

                    //upload img only if img is selected
                    if($image_name != "")
                    {                       

                        //auto rename img to avoid overrwiting images
                        //get img ext (jpg,png,gif,etc) example: "milk-tea.jpg"
                        $ext = end(explode('.', $image_name));

                        //Rename the img
                        $image_name = "food_category_".rand(000,999).'.'.$ext;


                        $source_path = $_FILES['image']['tmp_name'];
                        $destination_path = "../images/category/".$image_name;

                        //upload img
                        $upload = move_uploaded_file($source_path, $destination_path);

                        //Check if image is uploaded
                        //If img not uploaded, stop process and redirect with error msg
                        if($upload==false)
                        {
                            //set error msg
                            $_SESSION['upload'] = "<div class='error'>Failed to upload image</div>";
                            header('location:'.SITEURL.'admin/add-category.php');
                            //stop the process
                            die();
                        }
                    }
                }
                else
                {
                    //Don't upload img to DB, set image_name value as blank
                    $image_name = "";
                }

                //Query to insert into DB
                $sql = "INSERT INTO tbl_category SET
                  title = '$title',
                  image_name = '$image_name',
                  featured = '$featured',
                  active = '$active'  
                ";

                //Execute Query
                $res = mysqli_query($conn, $sql);

                //Check if query is executed
                if($res==true)
                {
                    //Successful, category added
                    $_SESSION['add'] = "<div class='success'>Category Added Successfully.</div>";
                    header('location:'.SITEURL.'admin/manage-category.php');
                }
                else
                {
                    //Fail, failed to add category
                    $_SESSION['add'] = "<div class='error'>Failed to Add Category.</div>";
                    header('location:'.SITEURL.'admin/add-category.php');
                }
            }

        ?>

    </div>
</div>


<?php include('partials/footer.php'); ?>