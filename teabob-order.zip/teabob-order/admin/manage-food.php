<?php include('partials/menu.php'); ?>


    <!-- Main content start -->
    <div class="main-content">
        <div class="wrapper">


           <?php if(isset($_SESSION['login']))
                {
                    echo $_SESSION['login']; //display ADD session msg
                    unset($_SESSION['login']); //remove the session msg after refresh
                } ?><br>

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql = "SELECT * FROM tbl_category";
                        //execute query
                        $res = mysqli_query($conn, $sql);
                        //count rows
                        $count = mysqli_num_rows($res);
                    ?>
                    <h1><?php echo $count; ?></h1>
                    <br>
                    Categories
                </div> 

                <div class="col-4 text-center">

                <?php 
                        //sql query
                        $sql2 = "SELECT * FROM tbl_food";
                        //execute query
                        $res2 = mysqli_query($conn, $sql2);
                        //count rows
                        $count2 = mysqli_num_rows($res2);
                    ?>
                    <h1><?php echo $count2; ?></h1>
                    <br>
                    Foods
                </div> 

                <div class="col-4 text-center">

                     <?php 
                        //sql query
                        $sql3 = "SELECT * FROM tbl_order";
                        //execute query
                        $res3 = mysqli_query($conn, $sql3);
                        //count rows
                        $count3 = mysqli_num_rows($res3);
                    ?>
                    <h1><?php echo $count3; ?></h1>
                    <br>
                    Total Orders
                </div> 

                <div class="col-4 text-center">

                    <?php 
                        //Create sql query to get total revenue generated
                        //Aggregate functionin sql
                        $sql4 = "SELECT SUM(total)AS total FROM tbl_order WHERE status='Delivered'";

                        //execute the query
                        $res4 = mysqli_query($conn, $sql4);
                        //get value
                        $row4 = mysqli_fetch_assoc($res4);

                        //get total revenue
                        $total_revenue = $row4['total'];
                    ?>
                    <h1><?php echo $total_revenue; ?></h1>
                    <br>
                    Revenue Generated 
                </div> 


        </div>
        <div class="clearfix"></div>
    </div>
  
<!-- Main content start -->
<div class="main-content">
    <div class="wrapper">
        
        <h1>Manage Food</h1>

        <br><br>
        <!-- Button to add -->
        <a href="<?php echo SITEURL; ?>admin/add-food.php" class="btn-primary">Add Food</a>
            <br /><br /><br />

            <?php
                if(isset($_SESSION['add']))
                {
                    echo $_SESSION['add'];
                    unset($_SESSION['add']);
                }

                if(isset($_SESSION['delete']))
                {
                    echo $_SESSION['delete'];
                    unset($_SESSION['delete']); 
                }
                if(isset($_SESSION['upload']))
                {
                    echo $_SESSION['upload'];
                    unset($_SESSION['upload']); 
                }
                if(isset($_SESSION['unauthorize']))
                {
                    echo $_SESSION['unauthorize'];
                    unset($_SESSION['unauthorize']); 
                }
                if(isset($_SESSION['update']))
                {
                    echo $_SESSION['update'];
                    unset($_SESSION['update']); 
                }

            ?>

        <table class="tbl-full">
                <tr>
                    <th>Food ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr> 
                
                <?php
                    //create a sql query to pull the data of food
                    $sql = "SELECT * FROM tbl_food";

                    //execute the query
                    $res = mysqli_query($conn, $sql);

                    //check rows if there is a food or not
                    $count = mysqli_num_rows($res);

                    //create serial number variable and set  default value as 1
                    $sn=1;

                    if($count>0)
                    {
                        //have food in DB
                        //get food from DB and display
                        while($row=mysqli_fetch_assoc($res))
                        {
                            //get values from individual columns
                            $id = $row['id'];
                            $title = $row['title'];
                            $price = $row['price'];
                            $image_name = $row['image_name'];
                            $featured = $row['featured'];
                            $active = $row['active'];
                            ?>


                        <tr>
                            <td><?php echo $sn++; ?>. </td>
                            <td><?php echo $title; ?></td>
                            <td>₱ <?php echo $price; ?></td>
                            <td>
                                <?php 
                                //check if have image or not
                                if($image_name=="")
                                {
                                    //don't have image will display message
                                    echo "<div class='error'>Image is not added</div>";
                                }
                                else
                                {
                                    //will display image
                                    ?>
                                    <img src="<?php echo $image_name; ?> " width="100px" height="100px">
                                    <?php
                                }
                                ?>
                            </td>
                            <td><?php echo $featured; ?></td>
                            <td><?php echo $active; ?></td>
                            <td>
                                <a href="<?php echo SITEURL; ?>admin/update-food.php? id=<?php echo $id; ?>" class="btn-secondary">Update Food</a>
                                <a href="<?php echo SITEURL; ?>admin/delete-food.php? id=<?php echo $id; ?>&image_name=<?php echo $image_name;?>" class="btn-danger">Delete Food</a>
                            </td>
                        </tr>

                            <?php

                        }
                    }
                    else
                    {
                        //not added food in DB
                        echo "<tr> <td colspan='7' class='error'>Food not added yet. </td> </tr>";
                    }
                ?>

            </table>

    </div>

    
</div>

    

    <!-- Main content end -->

<?php include('partials/footer.php'); ?>