<?php
    //include constants.php for SITEURL
    include('../config/constants.php');
    //Destroy session
    session_destroy(); //unsets $_SESSION['user']
    //Redirect to login.php
    header('location:'.SITEURL.'admin/login.php');
?>